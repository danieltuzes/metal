// readpgm.cpp : Defines the entry point for the console application.
//

#include "stdafx.h"
#include "pgmreader.h"



int main () {
	int i, j, k, m, maxfileszam, pixelszam;		//i,j,k bels� v�ltoz�k, m a pixelsorsz�mokon megy v�gig, max �rt�ke a pgm felbont�sa
	_PGMData pgmimagein;
	readPGM ("1.pgm",&pgmimagein);				//1.pgm filenak l�teznie kell, s olyannak kell lennie t�pusban, mint a t�bbinek
	maxfileszam = 1000;							//eddig pr�b�lja megnyitni a pgm filkeokat, de ha a k�vetkez�t nem tal�lja, le�ll
	pixelszam = pgmimagein.col * pgmimagein.row;
	char inputfilename[255];
	char outputfilename[255];
	double ** fmx;
	fmx = new double * [maxfileszam];			//ebben a t�mbben t�rol�dik az �sszes k�p �rt�ke "norm�lva"
	for (i=0; i<maxfileszam; i++) {
		fmx[i] = new double [pixelszam];
	}
	int * tmpintv;								// ebbe olvas�dik be a m�trix �r�ke
	tmpintv = new int [pixelszam];
	double norm, normtest;						//a norm�l�si �rt�k t�rol�s�hoz
	printf("Kepek beolvasasa...\n");
	for (i=0; i<maxfileszam; i++) {
		sprintf(inputfilename,"%i.pgm",i+1);
		FILE * inputf;
		inputf = fopen(inputfilename,"r");
		if (inputf == NULL) {
			printf("%s file nem elerheto, olvasas vege\n",inputfilename);
			maxfileszam = i;
			break;
			}
		fclose(inputf);
		readPGM (inputfilename,&pgmimagein);
		m=0;
		norm=0;
		printf("%s\r",inputfilename);		
		for (j=0; j<pgmimagein.row; j++) {
			for (k=0; k<pgmimagein.col; k++) {
				fmx[i][m] = (double) pgmimagein.matrix[j][k];
				m++;
			}
		}
	}
	printf("Kepek beolvasva, matrix normalasa\n");
	for (j=0; j<pixelszam; j++) {
		norm=0;
		for (i=0; i<maxfileszam; i++) {	
			norm += fmx[i][j];
			}
		for (i=0; i<maxfileszam; i++) {
			fmx[i][j] -= norm/maxfileszam;
			}
		}
	
	/*normtest = 0;
	for (i=0; i<maxfileszam; i++) {
			normtest += fmx[i][0];
			}
	printf("normtest0 = %f\n",normtest);

	for (i=0; i<maxfileszam; i++) {
			normtest += fmx[i][4];
			}
	printf("normtest3 = %f\n",normtest);

	for (i=0; i<maxfileszam; i++) {
			normtest += fmx[i][pixelszam];
			}
	printf("normtest_pixelszam = %f\n",normtest);*/
	
	
	FILE * pgmtestfileout;
	sprintf(outputfilename,"test_%s",inputfilename);
	pgmtestfileout = fopen(outputfilename,"w");
	m=0;
	fprintf(pgmtestfileout,"P2\n%i\t%i\n%i\n",pgmimagein.col,pgmimagein.row,pgmimagein.max_gray);
	for (j=0; j<pgmimagein.row; j++) {
		for (k=0; k<pgmimagein.col; k++) {
			fprintf(pgmtestfileout,"%i\t", (int) fmx[0][m]);
			m++;
		}
		fprintf(pgmtestfileout,"\n");
	}
	inputfilename[0] = getchar();
	return 0;
}
