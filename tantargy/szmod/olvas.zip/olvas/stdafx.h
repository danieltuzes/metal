// stdafx.h : include file for standard system include files,
// or project specific include files that are used frequently, but
// are changed infrequently
//
/* ez a r�sz nem kell annak valszeg, aki nem MSVS-ban programoz
#pragma once

#include "targetver.h"*/

#include <stdio.h>
#include <cstdlib>
#include <cctype>
#include <cmath>
#include <iostream>



// TODO: reference additional headers your program requires here
